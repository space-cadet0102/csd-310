import mysql.connector

db=mysql.connector.connect(host="localhost", user="root", password="P@ssw@rd123", database="bacchus", port="3307")


cursor=db.cursor()
cursor.execute("SELECT * FROM customers")
customers = cursor.fetchall()
for customers in customers:
	print("customer_id: {}\n f_name:{}\n l_name:{}\n address:{}\n inv_id:{}\n order_id:{}\n".format(customers[0], customers[1], customers[2], customers[3], customers[4], customers[5]))

cursor = db.cursor()
cursor.execute("SELECT * FROM wine_inventory")
wine_inventory = cursor.fetchall()
for wine_inventory in wine_inventory:
    print("inv_id: {}\n inv_name:{}\n inv_total:{}\n".format(wine_inventory[0], wine_inventory[1], wine_inventory[2]))

cursor = db.cursor()
cursor.execute("SELECT * FROM distributor")
distributor = cursor.fetchall()
for distributor in distributor:
    print("distributor_id: {}\n distributor_name:{}\n".format(distributor[0], distributor[1]))

cursor = db.cursor()
cursor.execute("SELECT * FROM orders")
orders = cursor.fetchall()
for orders in orders:
    print("order_id: {}\n order_name:{}\n order_date:{}\n customer_id:{}\n order_qty:{}\n".format(orders[0], orders[1], orders[2], orders[3],orders[4]))

cursor = db.cursor()
cursor.execute("SELECT * FROM supply_inventory")
supply_inventory = cursor.fetchall()
for supply_inventory in supply_inventory:
    print("supply_id: {}\n supply_name:{}\n supply_total:{}\n".format(supply_inventory[0], supply_inventory[1], supply_inventory[2]))

cursor = db.cursor()
cursor.execute("SELECT * FROM supplier")
supplier = cursor.fetchall()
for supplier in supplier:
    print("supplier_id: {}\n supplier_name:{}\n delivery_date:{}\n".format(supplier[0], supplier[1], supplier[2]))

cursor = db.cursor()
cursor.execute("SELECT * FROM employees")
employees = cursor.fetchall()
for employees in employees:
    print("employee_id: {}\n employee_fname:{}\n employee_lname:{}\n clock_in:{}\n clock_out:{}\n".format(orders[0], employees[1], employees[2], employees[3],employees[4]))
